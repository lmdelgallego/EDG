bootstrap-player
================

A Non-Intrusive HTML5 Audio Player Skin For Twitter Bootstrap

Requires:

  * Twitter Bootstrap - http://twitter.github.com/bootstrap/
  * jQuery - http://jquery.com/

Firefox Support Requires

  * html5slider - https://github.com/fryn/html5slider/

Additional Features When Using

  * Font Awesome - http://fortawesome.github.com/Font-Awesome/
